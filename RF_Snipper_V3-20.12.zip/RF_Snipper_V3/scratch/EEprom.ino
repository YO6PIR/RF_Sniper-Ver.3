/****************** EEPROM DataROM initialization **********************************************/        
void InitEEprom(){
    int DataROM = eprom.read(EEP_INIT);          //verifica locatia initiala daca este scrisa
  if(DataROM != 73){/*Salut!*/                   // Check if 24Cxx memory is Blanc → DataROM = 0xFF
    eprom.write(EEP_MODE, 2);                    //Default Mode = 2 [VOB]

    eep_LO = IF_FREQ;                            //valoarea initiala LO=25MHz  
    eprom.put((EEP_XTAL),eep_LO);

    eep_romadd = 0x010;                              
    eep_cal_factor=222222;                        //Default CalFactor = 222222
    eprom.put((eep_romadd),eep_cal_factor);
    eep_swr_offset=30;
    eprom.put(eep_romadd+4,eep_swr_offset);
    eep_X0=3850;
    eprom.put(eep_romadd+8,eep_X0);
    eep_X1=460;
    eprom.put(eep_romadd+12,eep_X1);
    eep_Y0=3725;
    eprom.put(eep_romadd+16,eep_Y0);
    eep_Y1=175;
    eprom.put(eep_romadd+20,eep_Y1);

    eep_incidentPower_dBm=-7.0;                  //(puterea incidentă reală Default)
    eprom.put(eep_romadd+24,eep_incidentPower_dBm);
    eep_incidentOffset_dBm=0.0;                  //(corecția reflectată Default)
    eprom.put(eep_romadd+28,eep_incidentOffset_dBm);

    eprom.write(EEP_INIT, 73);                    // Initialyzed End code "73=Salut!"
  }
  eep_romadd=0x010;    
  eprom.get(EEP_XTAL, eep_LO);              LO = eep_LO;
  eprom.get(eep_romadd, eep_cal_factor);    cal_factor = eep_cal_factor;  
  eprom.get(eep_romadd+4,eep_swr_offset);   SWR_offset = eep_swr_offset;
  eprom.get(eep_romadd+8,eep_X0);           X0=eep_X0;
  eprom.get(eep_romadd+12,eep_X1);          X1=eep_X1;
  eprom.get(eep_romadd+16,eep_Y0);          Y0=eep_Y0;
  eprom.get(eep_romadd+20,eep_Y1);          Y1=eep_Y1;
  eprom.get(eep_romadd+24,eep_incidentPower_dBm);  //  incidentPower_dBm = eep_incidentPower_dBm;
  eprom.get(eep_romadd+28,eep_incidentOffset_dBm);  // incidentOffset_dBm = eep_incidentOffset_dBm; 
  
  eprom.get(EEP_MODE,eep_mode);             Mode = eep_mode; //citeste ultimul mod de lucru salvat in memorie

}

/******** Versiune inscriptionata automat la compilare **********************/
String getVersion() {
  String date = __DATE__;   //* exemplu: "Nov  3 2025" 
  String day = date.substring(4, 6);
  String month = date.substring(0, 3);

  //* Convertim luna text în număr*
  String months = "JanFebMarAprMayJunJulAugSepOctNovDec";
  int m = (months.indexOf(month) / 3) + 1;

  // * Formatăm: Ver.3.zz.mm
  char buf[20];
  sprintf(buf, "Ver 3.%02d.%02d", day.toInt(), m);
  return String(buf);
}

#include <math.h>
#include <stdint.h>
#include <stdio.h>

// --- Parametri ADC / hardware ---
#define ADC_MAX      4095.0f
#define VREF         3.3f
#define ADC_CHANNEL  9    // PB1 -> ADC1_IN9

// --- EMA coefficients ---
#define EMA_FAST 0.25f
#define EMA_SLOW 0.03f

// --- Calibrare / conversie ---
typedef struct {
    float cal_50;     // ADC counts la 50 ohm (medie)
    float cal_open;   // ADC counts la OPEN
    float cal_short;  // ADC counts la SHORT
    // Conversie V -> dBm (opțional) : dBm = (V - intercept) / slope
    // sau alternativ V = intercept + slope * dBm
    // vom stoca slope [V per dB] și intercept [V @ 0 dBm]
    float slope;      // V per dB (sau 0 dacă necunoscut)
    float intercept;  // V la 0 dBm
    uint8_t haveDbmCalibration;
} Calib_t;

static Calib_t calib = {
    .cal_50 = 1500.0f,
    .cal_open = 3000.0f,
    .cal_short = 3100.0f,
    .slope = 0.0f,
    .intercept = 0.0f,
    .haveDbmCalibration = 0
};

// --- filtre EMA (statice) ---
static float adcFast = 0.0f;
static float adcSlow = 0.0f;

// Prototipuri (foloseste rutinele tale existente)
unsigned int citireADCmediatFast(uint8_t channel); // deja ai
// --- save/load stubs (implementeaza salvare in flash daca vrei) ---
void saveCalibration(void) {
    // TODO: scrie struct calib in flash/EEPROM
}
void loadCalibration(void) {
    // TODO: citeste din flash/EEPROM; daca nu exista lasa valorile default
}

// --- utilitare ---
static inline float adcCountsToVolt(float counts) {
    return counts * (VREF / ADC_MAX);
}

// --- functie principala de masurare (|Gamma|, SWR, RL, optional dBm) ---
void measureReflect(float* outGamma, float* outSWR, float* outRL, float* outDbm)
{
    // 1) citire ADC mediat rapid
    unsigned int raw = citireADCmediatFast(ADC_CHANNEL);

    // 2) EMA dublu
    adcFast = adcFast * (1.0f - EMA_FAST) + (float)raw * EMA_FAST;
    adcSlow = adcSlow * (1.0f - EMA_SLOW) + adcFast * EMA_SLOW;

    float x_counts = adcSlow;            // ADC counts filtrate
    float x_volts  = adcCountsToVolt(x_counts);

    // 3) Normalizare pentru |Gamma| pe baza calibrarii 50/open/short
    float ref_high = (calib.cal_open + calib.cal_short) * 0.5f;
    float ref_low  = calib.cal_50;
    float norm = 0.0f;
    if (ref_high != ref_low) {
        norm = (x_counts - ref_low) / (ref_high - ref_low);
    }
    if (norm < 0.0f) norm = 0.0f;
    if (norm > 1.0f) norm = 1.0f;

    float gamma = norm;
    if (gamma >= 0.9999f) gamma = 0.9999f;

    // 4) SWR si RL
    float SWR = (1.0f + gamma) / (1.0f - gamma);
    float RL = -20.0f * log10f(gamma + 1e-9f);

    // 5) dBm (daca avem calibratre V->dBm)
    float dbm = 0.0f;
    if (calib.haveDbmCalibration && fabsf(calib.slope) > 1e-12f) {
        // interpretare: V = intercept + slope * dBm  => dBm = (V - intercept) / slope
        dbm = (x_volts - calib.intercept) / calib.slope;
    } else {
        // fallback: invalid
        dbm = NAN;
    }

    // 6) iesiri
    if (outGamma) *outGamma = gamma;
    if (outSWR)   *outSWR   = SWR;
    if (outRL)    *outRL    = RL;
    if (outDbm)   *outDbm   = dbm;
}

// --- Calibrare 3 puncte (se apeleaza manual in mod interactiv) ---
// Apel: dupa montajul final, efectuezi: CalibCal50(), CalibOpen(), CalibShort()
void CalibCal50(void) {
    calib.cal_50 = (float) citireADCmediatFast(ADC_CHANNEL);
}
void CalibOpen(void) {
    calib.cal_open = (float) citireADCmediatFast(ADC_CHANNEL);
}
void CalibShort(void) {
    calib.cal_short = (float) citireADCmediatFast(ADC_CHANNEL);
    // optional: auto-save dupa calibrari
    saveCalibration();
}

// --- Calibrare dBm cu 2 puncte (daca ai sursa calibrata) ---
// P1 , P2: puterile injectate in dBm la intrarea lanţului (ex: -20.0f, -40.0f)
// V1, V2 sunt tensiunile masurate (V) la acele nivele
// Se calculeaza slope (V per dB) si intercept (V @ 0dBm)
int CalibDbm_2point(float P1_dBm, float P2_dBm, float V1_volt, float V2_volt)
{
    if (fabsf(P1_dBm - P2_dBm) < 1e-6f) return -1; // eroare
    float slope = (V1_volt - V2_volt) / (P1_dBm - P2_dBm); // V per dB
    float intercept = V1_volt - slope * P1_dBm;            // V @ 0 dBm
    calib.slope = slope;
    calib.intercept = intercept;
    calib.haveDbmCalibration = 1;
    saveCalibration();
    return 0;
}

// --- Helper pentru a colecta V (face N masuratori si medie) ---
float measureVoltageAverage(int samples)
{
    uint32_t s = 0;
    for (int i = 0; i < samples; ++i) {
        s += citireADCmediatFast(ADC_CHANNEL);
    }
    float avg_counts = (float)s / samples;
    return adcCountsToVolt(avg_counts);
}

float getRL_dB()
{
    int adc = citireADCmediatFast(9);   // tu ai deja funcția asta
    float volts = adc * (3.3f / 4095.0f);

    // calibrarea ta reală ↓
    float RL = (volts - offset_mV) / slope_mV_dB;

    return RL;
}

void masurareSWR()
{
    float RL = getRL_dB();        // măsoară Return Loss în dB
    float swr = RL_to_SWR(RL);    // convertește în SWR

    Serial1.print("RL = "); Serial1.print(RL, 2);
    Serial1.print(" dB   SWR = ");
    Serial1.println(swr, 2);

    // dacă vrei să desenezi pe ILI9341
    tft.setCursor(10, 20);
    tft.printf("RL: %.2f dB", RL);
    tft.setCursor(10, 40);
    tft.printf("SWR: %.2f", swr);
}
